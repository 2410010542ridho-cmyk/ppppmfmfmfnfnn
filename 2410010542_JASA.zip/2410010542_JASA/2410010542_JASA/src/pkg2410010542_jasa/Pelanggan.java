package pkg2410010542_jasa; // Pastikan kelas ini diletakkan di dalam package 'jasa'

import java.util.ArrayList;

public class Pelanggan {
    
    // Properti Individu
    private String idPelanggan;
    private String nama;
    private String tipe;
    private String statusAktif;
    private String telepon;
    
    // Properti Koleksi (ArrayList)
    private ArrayList<String> dataIdPelanggan;
    private ArrayList<String> dataNama;
    private ArrayList<String> dataTipe;
    private ArrayList<String> dataStatusAktif;
    private ArrayList<String> dataTelepon;
    
    // Constructor
    public Pelanggan() {
        this.dataIdPelanggan = new ArrayList<>();
        this.dataNama = new ArrayList<>();
        this.dataTipe = new ArrayList<>();
        this.dataStatusAktif = new ArrayList<>();
        this.dataTelepon = new ArrayList<>();
    }
    
    // --- METHOD UNTUK ARRAYLIST (STANDAR PATOKAN) ---
    
    public void inputDataId(String id) {
        this.dataIdPelanggan.add(id);
    }
    
    public ArrayList<String> listDataId() {
        return this.dataIdPelanggan;
    }
    
    public void inputDataNama(String nama) {
        this.dataNama.add(nama);
    }
    
    public ArrayList<String> listDataNama() {
        return this.dataNama;
    }
    
    public void inputDataTipe(String tipe) {
        this.dataTipe.add(tipe);
    }
    
    public ArrayList<String> listDataTipe() {
        return this.dataTipe;
    }
    
    public void inputDataStatus(String status) {
        this.dataStatusAktif.add(status);
    }
    
    public ArrayList<String> listDataStatus() {
        return this.dataStatusAktif;
    }
    
    public void inputDataTelepon(String telepon) {
        this.dataTelepon.add(telepon);
    }
    
    public ArrayList<String> listDataTelepon() {
        return this.dataTelepon;
    }
}