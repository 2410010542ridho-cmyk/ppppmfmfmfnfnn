package pkg2410010542_jasa; 
import javax.swing.*;
import formPelanggan.frameUtama;
// ... sisa kode ...


public class Main {

    // ===================== CLASS PELANGGAN =====================
    static class Pelanggan {
        private int idPelanggan;
        private String nama;
        private String alamat;
        private String noHp;

        // Constructor
        public Pelanggan(int idPelanggan, String nama, String alamat, String noHp) {
            this.idPelanggan = idPelanggan;
            this.nama = nama;
            this.alamat = alamat;
            this.noHp = noHp;
        }

        // Method Procedure (void)
        public void tampilkanData() {
            System.out.println("=== DATA PELANGGAN ===");
            System.out.println("ID: " + idPelanggan);
            System.out.println("Nama: " + nama);
            System.out.println("Alamat: " + alamat);
            System.out.println("No HP: " + noHp);
        }

        // Getter & Setter
        public int getIdPelanggan() {
            return idPelanggan;
        }

        public void setIdPelanggan(int idPelanggan) {
            this.idPelanggan = idPelanggan;
        }

        public String getNama() {
            return nama;
        }

        public void setNama(String nama) {
            this.nama = nama;
        }

        public String getAlamat() {
            return alamat;
        }

        public void setAlamat(String alamat) {
            this.alamat = alamat;
        }

        public String getNoHp() {
            return noHp;
        }

        public void setNoHp(String noHp) {
            this.noHp = noHp;
        }
    }

    // ===================== CLASS PESANAN =====================
    static class Pesanan {
        private int idPesanan;
        private String tanggal;
        private String jenisPerangkat;
        private String keluhan;

        // Constructor
        public Pesanan(int idPesanan, String tanggal, String jenisPerangkat, String keluhan) {
            this.idPesanan = idPesanan;
            this.tanggal = tanggal;
            this.jenisPerangkat = jenisPerangkat;
            this.keluhan = keluhan;
        }

        // Method Procedure (void)
        public void tampilkanPesanan() {
            System.out.println("=== DATA PESANAN ===");
            System.out.println("ID Pesanan: " + idPesanan);
            System.out.println("Tanggal: " + tanggal);
            System.out.println("Jenis Perangkat: " + jenisPerangkat);
            System.out.println("Keluhan: " + keluhan);
        }

        // Getter & Setter
        public int getIdPesanan() {
            return idPesanan;
        }

        public void setIdPesanan(int idPesanan) {
            this.idPesanan = idPesanan;
        }

        public String getTanggal() {
            return tanggal;
        }

        public void setTanggal(String tanggal) {
            this.tanggal = tanggal;
        }

        public String getJenisPerangkat() {
            return jenisPerangkat;
        }

        public void setJenisPerangkat(String jenisPerangkat) {
            this.jenisPerangkat = jenisPerangkat;
        }

        public String getKeluhan() {
            return keluhan;
        }

        public void setKeluhan(String keluhan) {
            this.keluhan = keluhan;
        }
    }

    // ===================== MAIN METHOD =====================
    public static void main(String[] args) {
        
        // KODE PENYAMBUNG: Membuka frameUtama saat program dijalankan
        java.awt.EventQueue.invokeLater(() -> {
            new frameUtama().setVisible(true);
        });
        
    }
}

